#pragma once
#include <SFML/Graphics.hpp>
#include <Box2d.h>
#include <iostream>

using namespace std;
using namespace sf;

class FiguraVisual {

private:

	//Dimensiones del rect�ngulo
	Vector2f dimensiones;

	//Punteros a los 2 tipos de figura visual
	RectangleShape* figura_rectangular;

public:

	//Constructores
	FiguraVisual(Vector2f posicion);
	FiguraVisual(Vector2f posicion, Vector2f dimensiones_figura, Color color);

	//M�todos sin retorno
	void renderizar(RenderWindow* ventana);
	void crear(Color color, Vector2f posicion);
	void modificarOrigen(Vector2f offset);
	void rotar(float grados);
	void establecerRotacion(float grados);

	//M�todos con retorno
	Vector2f retornarPosicion();

};

