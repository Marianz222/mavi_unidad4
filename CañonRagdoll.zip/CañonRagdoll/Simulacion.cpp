#include "Simulacion.h"

//Constructor: Acepta como par�metros la dimension y el nombre de la ventana para el programa. Inicializa las variables y
//llama a m�todos de inicializaci�n
Simulacion::Simulacion(Vector2i dimensiones_programa, string nombre_programa) {

	//Iguala la variable de vector de dimension
	dimensiones_ventana = dimensiones_programa;

	//Iguala la variable de nombre
	nombre_ventana = nombre_programa;

	//Asigna una nueva ventana a la variable existente
	ventana = crearVentana(dimensiones_ventana.x, dimensiones_ventana.y, nombre_ventana);

	//Instancia el gestor de eventos
	gestor_eventos = new Event;

	//Se establece la gravedad y se suministra al mundo f�sico para su creaci�n
	gravedad = {0.0f, 0.02f};
	mundo = new b2World(gravedad);

	//Llamada a crear los elementos
	crearSala();
	crearObstaculos();
	crearArma();

}

//M�todo que llena los punteros a elementos con valores, instancia las 2 paredes y los dos techos
void Simulacion::crearSala() {

	//Guarda el tama�o de una pared y un suelo, usado para generar los 4 objetos
	b2Vec2 dimensiones_suelo = { 20.0f, 0.5f };
	b2Vec2 dimensiones_pared = { 0.5f, 9.75f };

	//Creaci�n de los delimitantes de la simulaci�n
	paredes[0] = new Poligono(dimensiones_suelo, { 19.0f, 21.0f }, mundo, Color::Blue, 0, PIXELES_POR_METRO); //Suelo
	paredes[1] = new Poligono(dimensiones_suelo, { 19.0f, 0.5f }, mundo, Color::Blue, 0, PIXELES_POR_METRO); //Techo
	paredes[2] = new Poligono(dimensiones_pared, { 0.5f, 10.75f }, mundo, Color::Cyan, 0, PIXELES_POR_METRO); //Pared izquierda
	paredes[3] = new Poligono(dimensiones_pared, { 38.0f, 10.75f }, mundo, Color::Cyan, 0, PIXELES_POR_METRO); //Pared derecha

}

//M�todo encargado de crear los obstaculos que aparecen por todo el mapa. Estos pueden ser din�micos o est�ticos
void Simulacion::crearObstaculos() {

	//Guarda todas las dimensiones en vectores f�sicos
	b2Vec2 dimensiones_plataforma = {3.0f, 0.25f};
	b2Vec2 dimensiones_caja = {0.75f, 0.75f};
	b2Vec2 dimensiones_rampa = {3.0f, 0.5f};

	//Crea cada uno de los objetos siendo estos: 2 Plataformas horizontales, 1 Rampa inclinada y 6 Cajas din�micas
	obstaculos[0] = new Poligono(dimensiones_plataforma, { 34.5f, 6.0f }, mundo, Color::White, 0, PIXELES_POR_METRO); //Plataforma derecha arriba
	obstaculos[1] = new Poligono(dimensiones_plataforma, { 16.0f, 10.0f }, mundo, Color::White, 0, PIXELES_POR_METRO); //Plataforma derecha abajo
	obstaculos[2] = new Poligono(dimensiones_rampa, { 25.0f, 15.0f }, mundo, Color::Yellow, 2, PIXELES_POR_METRO); //Rampa
	obstaculos[3] = new Poligono(dimensiones_caja, { 34.0f, 4.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #1
	obstaculos[4] = new Poligono(dimensiones_caja, { 32.5f, 4.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #2
	obstaculos[5] = new Poligono(dimensiones_caja, { 33.0f, 3.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #3
	obstaculos[6] = new Poligono(dimensiones_caja, { 14.0f, 9.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #4
	obstaculos[7] = new Poligono(dimensiones_caja, { 16.0f, 9.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #5
	obstaculos[8] = new Poligono(dimensiones_caja, { 15.0f, 8.0f }, mundo, Color::Red, 1, PIXELES_POR_METRO); //Caja Din�mica #6

	//Asigna la rotaci�n de la rampa contenida en el arreglo
	obstaculos[2]->modificarRotacion(-35.0f);

	//Itera sobre cada elemento del arreglo de 9 obst�culos
	for (int i = 3; i < 9; i++) {

		//Si el puntero obtenido es nulo
		if (obstaculos[i] == nullptr) {

			//Salta a la siguiente iteraci�n del bucle for
			continue;

		}

		//Aplica la fuerza inicial a las cajas
		obstaculos[i]->aplicarFuerza({0.0f, 10.0f});

	}

}

void Simulacion::crearArma() {

	//Almacena las dimensiones de ambas partes
	b2Vec2 dimensiones_base = {2.0f, 2.0f};
	b2Vec2 dimensiones_barril = {5.0f, 2.0f};
	
	//Almacena la posici�n de ambas partes
	b2Vec2 posicion_base = {4.0f, 19.5f};
	b2Vec2 posicion_barril = {4.0f, 19.5f};

	//Variables que almacenan el color de las figuras
	Color color_base = Color::White;
	Color color_barril = Color::Yellow;

	//Vectores gr�ficos que almacenan las dimensiones convertidas a pixeles para crear las figuras visuales
	Vector2f dimensiones_base_convertidas = {dimensiones_base.x * PIXELES_POR_METRO, dimensiones_base.y * PIXELES_POR_METRO};
	Vector2f dimensiones_barril_convertidas = { dimensiones_barril.x * PIXELES_POR_METRO, dimensiones_barril.y * PIXELES_POR_METRO };

	//Vectores gr�ficos que almacenan las posiciones convertidas a pixeles para posicionar las figuras visuales
	Vector2f posicion_base_convertida = {posicion_base.x * PIXELES_POR_METRO, posicion_base.y * PIXELES_POR_METRO};
	Vector2f posicion_barril_convertida = {posicion_barril.x * PIXELES_POR_METRO, posicion_barril.y * PIXELES_POR_METRO};

	//Se crean los objetos dentro de sus respectivos espacios del arreglo de punteros, usando los datos previamente establecidos
	arma[0] = new FiguraVisual(posicion_base_convertida, dimensiones_base_convertidas, color_base);
	arma[1] = new FiguraVisual(posicion_barril_convertida, dimensiones_barril_convertidas, color_barril);

	arma[1]->modificarOrigen({-125.0f, 0.0f});

}

//Este m�todo crea un ragdoll al ser llamado. Inserta un nuevo objeto en un puntero vac�o dentro del arreglo de punteros de ragdolls
//Recibe la fuerza aplicada al ragdoll por par�metro, dicha fuerza se aplica al generar el objeto
void Simulacion::crearRagdoll(Vector2f fuerza_impulso) {

	//Guarda el tama�o de cada parte del mu�eco
	b2Vec2 dimensiones_componentes[6];
	dimensiones_componentes[0] = { 0.25f, 0.25f }; //Dimensiones: Cabeza
	dimensiones_componentes[1] = { 0.5f, 0.75f }; //Dimensiones: Cuerpo

	//Bucle de 4 iteraciones que recorre desde �ndice "2" hasta �ndice "5" para fijar el tama�o (Brazos y Piernas)
	for (int i = 2; i < 6; i++) {

		//Establece las dimensiones para cada �ndice
		dimensiones_componentes[i] = { 0.2f, 0.5f }; //Dimensiones: Brazos y Piernas

	}

	////////////////////////////////////////////////////////////////////////////

	//Almacena la posicion centro y en base a ella configura las posiciones iniciales para cada parte del cuerpo
	b2Vec2 posicion_centro = { 4.0f, 19.5f };
	b2Vec2 posiciones_componentes[6];
	posiciones_componentes[0] = { posicion_centro.x, posicion_centro.y - 1.0f }; //Posicion: Cabeza
	posiciones_componentes[1] = posicion_centro; //Posicion: Cuerpo
	posiciones_componentes[2] = { posicion_centro.x - 0.75f, posicion_centro.y - 0.25f }; //Posicion: Brazo Izquierdo
	posiciones_componentes[3] = { posicion_centro.x + 0.75f, posicion_centro.y - 0.25f }; //Posicion: Brazo Derecho
	posiciones_componentes[4] = { posicion_centro.x - 0.5f, posicion_centro.y + 1.25f }; //Posicion: Pierna Izquierda
	posiciones_componentes[5] = { posicion_centro.x + 0.5f, posicion_centro.y + 1.25f }; //Posicion: Pierna Derecha

	////////////////////////////////////////////////////////////////////////////

	//Establece los colores para cada parte del ragdoll
	Color colores[6];
	colores[0] = Color::White; //Color: Cabeza
	colores[1] = Color::Green; //Color: Cuerpo

	//Bucle de 4 iteraciones desde �ndice "2" hasta "5"
	for (int i = 2; i < 6; i++) {

		//Establece el color para cada �ndice
		colores[i] = Color::Yellow; //Color: Brazos y Piernas

	}

	////////////////////////////////////////////////////////////////////////////

	//Itera sobre el arreglo de ragdolls
	for (int i = 0; i < LIMITE_RAGDOLLS; i++) {

		//Si el puntero sobre el que se itera no es nulo...
		if (ragdolls[i] != nullptr) {

			//Pasa a la siguiente iteraci�n del bucle (Ya que se requiere un puntero vac�o para crear el objeto)
			continue;

		}

		//Inserta el nuevo objeto de ragdoll en el puntero vac�o encontrado
		ragdolls[i] = new Ragdoll(dimensiones_componentes, posiciones_componentes, mundo, colores, 1, PIXELES_POR_METRO);

		//Convierte el "Vector2f" recibido a "b2Vec2" para ser suministrado como par�metro en la siguiente funci�n.
		//Esto debido a que el m�todo de aplicar fuerza trabaja con vectores de Box2D y requiere una conversion para ello
		b2Vec2 fuerza_fisica = { fuerza_impulso.x, fuerza_impulso.y };

		//Le aplica la fuerza al objeto ya creado, dicha fuerza se recibe al llamar la funci�n de creaci�n
		ragdolls[i]->aplicarFuerza(fuerza_fisica, 1);

		//Rompe el bucle para evitar crear m�ltiples ragdolls
		break;

	}

}

//M�todo simple que elimina el ragdoll m�s antiguo, asignando su puntero a nulo. Esto permite que se vuelvan a disparar
//ragdolls nuevos sin tener que reiniciar el programa o exceder el l�mite de entidades m�ximo asignado
void Simulacion::eliminarRagdoll() {

	//Itera sobre todo el arreglo de ragdolls...
	for (int i = 0; i < LIMITE_RAGDOLLS; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (ragdolls[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Bucle interno para iterar sobre cada parte del ragdoll a eliminar
		for (int k = 0; k < 6; k++) {

			//Ingresa al componente del ragdoll sobre el que se itera y llama a su eliminaci�n suministrando el mundo f�sico
			ragdolls[i]->retornarComponente(k)->destruir(mundo);

		}

		//Borra el dato almacenado en la direcci�n obtenida
		delete ragdolls[i];

		//Asigna el puntero a nulo, ya que el dato al que apuntaba fue eliminado
		ragdolls[i] = nullptr;

		//Rompe el bucle para evitar que se eliminen m�s datos, limita la eliminaci�n a una por llamada a la funci�n
		break;

	}

}

//M�todo que permite aplicar una fuerza lineal al cuerpo suministrado por par�metro, usando el valor
void Simulacion::aplicarFuerza(b2Body* cuerpo, b2Vec2 valor) {

	//Se aplica el impulso lineal (valor) al cuerpo en el punto de origen elegido, despertandolo si est� dormido
	cuerpo->ApplyForceToCenter(valor, true);

}

//M�todo de bucle principal, en �l ocurre todo el manejo de la l�gica
void Simulacion::iniciarSimulacion() {

	//Mientras la ventana est� abierta...
	while (ventana->isOpen()) {

		//Llama a actualizar las f�sicas
		actualizarFisicas(10,8);

		//Llama a actualizar los elementos
		actualizarObjetos();

		//Ejecuta la gesti�n de eventos
		gestionarEventos();

		//Ejecuta la actualizaci�n del renderizado en la ventana
		actualizarRenderizado();

	}

}

//M�todo que genera una ventana con las dimensiones y nombre especificadas y luego la retorna para ser almacenada y usada
RenderWindow* Simulacion::crearVentana(int altura, int anchura, string nombre) {

	//Retorna una nueva ventana con los par�metros recibidos
	return new RenderWindow(VideoMode(anchura, altura), nombre);

}

//M�todo que recibe inserciones para dibujarlas en la pantalla, limpia y actualiza el contenido de la misma
void Simulacion::actualizarRenderizado() {

	//Limpia la pantalla
	ventana->clear();

	//Itera sobre los 4 elementos en paredes
	for (int i = 0; i < 4; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (paredes[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Pasa la ventana al elemento con la llamada a renderizar
		paredes[i]->renderizar(ventana);

	}

	//Itera sobre los 9 elementos del arreglo de obstaculos
	for (int i = 0; i < 9; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (obstaculos[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Llama a renderizar desde cada elemento, pasando la ventana
		obstaculos[i]->renderizar(ventana);

	}

	//Carga el arreglo de ragdolls para dibujar
	for (int i = 0; i < LIMITE_RAGDOLLS; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (ragdolls[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Actualiza el ragdoll en el espacio iterado
		ragdolls[i]->renderizar(ventana);

	}

	//Llama al renderizado de la base y el ca�on del arma
	arma[1]->renderizar(ventana);
	arma[0]->renderizar(ventana);

	//Muestra el contenido cargado
	ventana->display();

}

//M�todo encargado de procesar todos los inputs eventos del jugador sobre la ventana.
void Simulacion::gestionarEventos() {

	//Crea las variables a usar fuera de los estados switch para evitar errores
	//Variables para la reducci�n de fuerza, almacenar dicho valor y la fuerza total de impulso del ragdoll generado
	float reduccion;
	float fuerza_reducida;
	Vector2f fuerza_total;

	while (ventana->pollEvent(*gestor_eventos)) {

		switch (gestor_eventos->type) {

			//Evento: Cerrar ventana
		case Event::Closed:

			ventana->close();

			break;

			//Evento: Tecla Presionada
		case Event::KeyPressed:

			switch (gestor_eventos->key.code) {

				//Tecla: Escape - Cerrar la ventana
			case Keyboard::Escape:

				ventana->close();

				break;
				
			}

			//Evento: Bot�n del Cursor presionado
		case Event::MouseButtonPressed:

			switch (gestor_eventos->mouseButton.button) {

				//Boton: Izquierdo
			case Mouse::Left:

				//Se asigna el valor de la reducci�n. Este es el valor encargado de decrementar la fuerza conforme m�s lejos est�
				//el cursor del usuario del centro del ca�on, el cual es el punto de origen de los ragdolls
				reduccion = 0.001f;

				//Calcula la exponencial usando la reducci�n junto a la distancia del cursor
				fuerza_reducida = exp(reduccion * distancia_a_cursor);

				//Se multiplica la fuerza normal por la reducida, otorgando la fuerza final que ser� usada para disparar el ca�on
				fuerza_total = fuerza_impulso * fuerza_reducida;

				//Genera un ragdoll y lo inserta en el arreglo si hay espacio, lo dispara aplicando la fuerza final calculada anteriormente
				crearRagdoll(fuerza_total);

				//DEBUG
				//depurarEstadoArreglo();

				break;

				//Boton: Derecho
			case Mouse::Right:

				//Elimina el �ltimo ragdoll del arreglo, para poder generar uno nuevo
				eliminarRagdoll();

				//DEBUG
				//depurarEstadoArreglo();

				break;

			}

		}

	}

}

//M�todo que actualiza la simulaci�n fisica usando las iteraciones suministradas por par�metro
void Simulacion::actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion) {

	//Almacena el tiempo
	float tiempo = 1.0f / 60.0f;

	//Hace que el mundo f�sico avance, actualizado los objetos contenidos en �l
	mundo->Step(tiempo, iteraciones_velocidad, iteraciones_posicion);

}

//Encargado de actualizar la posici�n de los objetos visuales para encajar con la de sus contrapartes f�sicas
void Simulacion::actualizarObjetos() {

	//Actualiza el arreglo de ragdolls
	for (int i = 0; i < LIMITE_RAGDOLLS; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (ragdolls[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Actualiza el ragdoll en el espacio iterado
		ragdolls[i]->actualizar(PIXELES_POR_METRO);

	}
	

	//Bucle que itera sobre cada elemento de paredes
	for (int i = 0; i < 4; i++) {

		//Actualiza cada elemento
		paredes[i]->actualizar(PIXELES_POR_METRO);

	}

	//Bucle que itera sobre cada elemento del arreglo de obst�culos
	for (int i = 0; i < 9; i++) {

		//Si el puntero sobre el que se itera es nulo...
		if (obstaculos[i] == nullptr) {

			//Pasa a la siguiente iteraci�n del bucle
			continue;

		}

		//Actualiza cada elemento
		obstaculos[i]->actualizar(PIXELES_POR_METRO);

	}

	////////////////////////////////////

	//Define el multiplicador de fuerza, el cual servir� para amplificar la fuerza final aplicada al ragdoll tras ser disparado
	float multiplicador_fuerza = 40.0f;

	//Llama a la actualizaci�n del angulo de rotaci�n del arma y la distancia entre el arma y el cursor, suministrando el multiplicador
	actualizarMecanicasMovimiento(multiplicador_fuerza);

	//Fija la nueva rotaci�n, oponiendo el angulo y adicionando 90 grados para enfocar hacia el cursor
	arma[1]->establecerRotacion(angulo_arma);

}

//M�todo encargado de definir y modificar las variables que forman parte del disparo del ca�on, asi sea rotar el arma, obtener la
//distancia entre el cursor y la base del ca�on, o tambi�n hacer las operaciones que definir�n la fuerza de disparo. Recibe un modificador
//de impulso como par�metro, el cual aportar� al impulso final para disparar el objeto
void Simulacion::actualizarMecanicasMovimiento(float potencia_impulso) {

	//Almacena la posicion del cursor en un vector de n�meros enteros
	Vector2i posicion_cursor = Mouse::getPosition(*ventana);

	//Se actualiza la variable que almacena la distancia entre el ca�on y el cursor
	distancia_a_cursor = hypot(arma[1]->retornarPosicion().x - posicion_cursor.x, arma[1]->retornarPosicion().y - posicion_cursor.y);

	////////////////////////////////////

	//CALCULO DEL ANGULO DEL ARMA

	//Almacena la distancia entre el cursor y la base del arma
	float distancia_x = posicion_cursor.x - arma[1]->retornarPosicion().x;
	float distancia_y = posicion_cursor.y - arma[1]->retornarPosicion().y;

	//Almacena el nuevo angulo, calculando la distancia entre ambos puntos y convirtiendo los radianes a angulo
	float nuevo_angulo = atan2(distancia_x, distancia_y) * (180.0f / b2_pi);

	//Finalmente cambia el angulo a negativo y le a�ade 90 grados para coordinar la rotaci�n con el cursor
	angulo_arma = -nuevo_angulo + 90.0f;

	////////////////////////////////////

	//CALCULO DE LA FUERZA DE DISPARO

	//Variables de vector para almacenar la direccion de disparo tanto cruda como normalizada
	Vector2f direccion_disparo = Vector2f(posicion_cursor) - arma[1]->retornarPosicion();
	Vector2f direccion_normalizada = direccion_disparo / sqrt(direccion_disparo.x * direccion_disparo.x + direccion_disparo.y * direccion_disparo.y);

	//La fuerza se define multiplicando la nueva direcci�n transformada con la potencia de impulso suministrada al llamar a la funci�n
	fuerza_impulso = {direccion_normalizada * potencia_impulso};

}

//M�todo debug que imprime la posici�n y rotaci�n de un objeto por consola
void Simulacion::depurarTransformacion(Poligono objeto) {

	//Depura la posici�n f�sica y visual
	cout << "P. Fisica: " << objeto.retornarCuerpo()->GetPosition().x * PIXELES_POR_METRO << ", " << objeto.retornarCuerpo()->GetPosition().y * PIXELES_POR_METRO << endl;
	cout << "P. Visual: " << objeto.retornarVisual()->getPosition().x << ", " << objeto.retornarVisual()->getPosition().y << endl;

	//Depura la rotaci�n f�sica y visual
	cout << "R. Fisica: " << objeto.retornarCuerpo()->GetAngle() << endl;
	cout << "R. Visual: " << objeto.retornarVisual()->getRotation() * (b2_pi / 180.0f) << endl;

}

//M�todo debug que revisa cada posici�n del arreglo de ragdolls e imprime 1 o 0 si el espacio tiene o no un dato respectivamente
void Simulacion::depurarEstadoArreglo() {

	//Itera sobre el arreglo usando la constante est�tica definida en la cabecera de la clase
	for (int i = 0; i < LIMITE_RAGDOLLS; i++) {

		//Variable local bool
		bool tiene_dato = false;

		//Si el puntero seleccionado no es nulo...
		if (ragdolls[i] != nullptr) {

			//Hay un dato en el puntero
			tiene_dato = true;

		}

		//Depura dicha informaci�n en la consola
		cout << "[DEBUG]: Ragdoll - Espacio '" << i << "' = " << tiene_dato << endl;

	}

}