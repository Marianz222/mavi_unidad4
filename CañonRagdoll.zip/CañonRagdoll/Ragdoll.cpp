#include "Ragdoll.h"

//Constructor: Recibe las dimensiones y posiciones para los 6 componentes, un mundo f�sico donde crear los cuerpos, un arreglo de color,
//un bool para determinar si el ragdoll ser� din�mico o est�tico y finalmente la escala de pixeles por metro
Ragdoll::Ragdoll(b2Vec2 dimensiones_poligono[6], b2Vec2 posicion[6], b2World* mundo, Color color[6], bool es_dinamico, int pixeles_por_metro) {

	//Itera sobre cada objeto almacenado en el arreglo para insertar su nuevo elemento
	for (int i = 0; i < 6; i++) {

		//Genera los componentes del ragdoll a partir de los par�metros recibidos
		componentes[i] = new Poligono(dimensiones_poligono[i], posicion[i], mundo, color[i], es_dinamico, pixeles_por_metro);

	}

	//Llamada a crear las juntas/enlaces
	crearEnlaces(mundo, pixeles_por_metro);

}

//M�todo que se encarga de que los Poligonos componentes llamen a "renderizar", iterando sobre cada uno e iniciando la directiva
void Ragdoll::renderizar(RenderWindow* ventana) {

	//Itera sobre todos los elementos del ragdoll
	for (int i = 0; i < 6; i++) {

		if (componentes[i] == nullptr) {

			continue;

		}

		//Llama a "renderizar" para cada componente
		componentes[i]->renderizar(ventana);

	}
	
	//Itera sobre todos los enlaces de tipo junta
	for (int i = 0; i < 5; i++) {

		if (enlaces[i] == nullptr) {

			continue;

		}

		//Llama a "renderizar" para cada junta
		enlaces[i]->renderizar(ventana);

	}

}

//M�todo que se encarga de ejecutar la actualizaci�n para cada componente del ragdoll
void Ragdoll::actualizar(int pixeles_por_metro) {

	//Itera sobre cada componente del ragdoll
	for (int i = 0; i < 6; i++) {

		//Ejecuta la llamada a "actualizar"
		componentes[i]->actualizar(pixeles_por_metro);

	}

	//Itera sobre cada enlace
	for (int i = 0; i < 5; i++) {

		//Ejecuta la llamada a "actualizar"
		enlaces[i]->actualizar(pixeles_por_metro);

	}

}

//M�todo encargado de generar los enlaces usados para conectar las partes del ragdoll
void Ragdoll::crearEnlaces(b2World* mundo, int pixeles_por_metro) {
	
	//Se crean los enlaces y se almacenan en su arreglo. Las coordenadas de anclaje se pasan por valor, mientras que los dem�s
	//valores se pasan por referencia. Cada linea contiene un comentario para determinar qu� poligonos se unen
	enlaces[0] = new Enlace(componentes[1], componentes[0], { 0.0f, -0.7f }, { 0.0f, 0.2f }, mundo, pixeles_por_metro); //Cuerpo a Cabeza
	enlaces[1] = new Enlace(componentes[1], componentes[2], { -0.42f, -0.7f }, { 0.12f, -0.45f }, mundo, pixeles_por_metro); //Cuerpo a Brazo Izq.
	enlaces[2] = new Enlace(componentes[1], componentes[3], { 0.42f, -0.7f }, { -0.12f, -0.45f }, mundo, pixeles_por_metro); //Cuerpo a Brazo Der.
	enlaces[3] = new Enlace(componentes[1], componentes[4], { -0.45f, 0.7f }, { 0.0f, -0.45f }, mundo, pixeles_por_metro); //Cuerpo a Pierna Izq.
	enlaces[4] = new Enlace(componentes[1], componentes[5], { 0.45f, 0.7f }, { 0.0f, -0.45f }, mundo, pixeles_por_metro); //Cuerpo a Pierna Der.

}

//M�todo que aplica una fuerza a todas las partes del ragdoll
void Ragdoll::aplicarFuerza(b2Vec2 magnitud) {

	//Itera sobre los 6 componentes
	for (int i = 0; i < 6; i++) {

		//Aplica una fuerza al componente sobre el que se est� iterando
		componentes[i]->aplicarFuerza(magnitud);

	}

}

//M�todo que permite aplicar una fuerza a una �nica parte del ragdoll, usando la magnitud y el �ndice pasados por par�metro
void Ragdoll::aplicarFuerza(b2Vec2 magnitud, int indice_afectado) {

	//Aplica la fuerza al componente alojado en el �ndice afectado del arreglo
	componentes[indice_afectado]->aplicarFuerza(magnitud);

}

//M�todo que rota el ragdoll cambiando los grados de rotaci�n del cuerpo, el cual al estar conectado con las dem�s partes har� que
//todo el mu�eco rote en dicha direcci�n
void Ragdoll::rotar(float grados) {

	componentes[1]->modificarRotacion(grados);

}

////////////////////////////////////////////////////////////////////////////////

//Retorna un puntero a un componente del ragdoll, para ello se usa el �ndice suministrado por par�metro
Poligono* Ragdoll::retornarComponente(int indice) {

	//Switch con el indice
	switch (indice) {

	case 0: //Valor Obtenido: 0

		//Retorna el componente con el �ndice seleccionado
		return componentes[0];

		break;

	case 1: //Valor Obtenido: 1

		//Retorna el componente con el �ndice seleccionado
		return componentes[1];

		break;

	case 2: //Valor Obtenido: 2

		//Retorna el componente con el �ndice seleccionado
		return componentes[2];

		break;

	case 3: //Valor Obtenido: 3

		//Retorna el componente con el �ndice seleccionado
		return componentes[3];

		break;

	case 4: //Valor Obtenido: 4

		//Retorna el componente con el �ndice seleccionado
		return componentes[4];

		break;

	case 5: //Valor Obtenido: 5
		
		//Retorna el componente con el �ndice seleccionado
		return componentes[5];

		break;

	}

	//Si el valor obtenido no es igual a ningun caso controlado, se retorna el primer elemento (�ndice 0)
	return 0;

}
