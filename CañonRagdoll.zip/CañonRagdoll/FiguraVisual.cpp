#include "FiguraVisual.h"

//Constructor por Defecto: Genera una figura cuadrada de color blanco en la posici�n suministrada por par�metro
FiguraVisual::FiguraVisual(Vector2f posicion) {

	//Asigna dimensiones por defecto
	dimensiones = {50.0f, 50.0f};

	//Guarda un color por defecto
	Color color = Color::White;

	//Llama a crear la figura con los par�metros por defecto creados
	crear(color, posicion);

}

//Constructor Compuesto: Recibe como par�metro la posici�n del objeto, sus dimensiones y su color
FiguraVisual::FiguraVisual(Vector2f posicion, Vector2f dimensiones_figura, Color color) {

	//Guarda la variable recibida en el atributo propio de la clase
	dimensiones = dimensiones_figura;

	//Llama a crear con los par�metros recibidos
	crear(color, posicion);

}

//Encargado de crear el objeto dentro del puntero, personalizando sus propiedades como el color, tama�o, posicion y origen por defecto
void FiguraVisual::crear(Color color, Vector2f posicion) {

	//Crea el objeto en el puntero
	figura_rectangular = new RectangleShape();

	//Asigna la dimension del rect�ngulo, su origen, su color y llama a actualizar su posici�n
	figura_rectangular->setSize(dimensiones);
	figura_rectangular->setOrigin(dimensiones.x / 2, dimensiones.y / 2);
	figura_rectangular->setFillColor(color);
	figura_rectangular->setPosition(posicion);

}

//Recibe un puntero a una ventana para poder pasar la directiva de dibujar en ella
void FiguraVisual::renderizar(RenderWindow* ventana) {

	ventana->draw(*figura_rectangular);

}

//M�todo que permite modificar o cambiar el origen del objeto con uno personalizado, usando el offset suministrado como par�metro
void FiguraVisual::modificarOrigen(Vector2f offset) {

	//Guarda el origen, obteniendo el punto central de cada eje y sumando el offset que suministra el usuario
	Vector2f origen = {figura_rectangular->getSize().x / 2 + offset.x, figura_rectangular->getSize().y / 2 + offset.y};

	//Establece el nuevo origen
	figura_rectangular->setOrigin(origen);

}

//Permite rotar la figura definiendo los grados como par�metro recibido. A�ade a la rotaci�n base del objeto (no la sobreescribe)
void FiguraVisual::rotar(float grados) {

	//A�ade a la rotaci�n base del objeto
	figura_rectangular->rotate(grados);

}

//Permite sobreescribir la rotaci�n del objeto con el par�metro recibido. Asigna la rotaci�n del objeto en lugar de a�adir sobre ella
void FiguraVisual::establecerRotacion(float grados) {

	//A�ade a la rotaci�n base del objeto
	figura_rectangular->setRotation(grados);

}

//////////////////////////////////////////////////////////////////

//Retorna un vector representando la posici�n del rectangulo visual
Vector2f FiguraVisual::retornarPosicion() {

	return figura_rectangular->getPosition();

}