#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <box2d.h>
#include <iostream>
#include <cstdlib>

#include "Poligono.h"
#include "Ragdoll.h"
#include "FiguraVisual.h"

using namespace std;
using namespace sf;

class Simulacion {

private:

	//Constante que define a cuantos pixeles equivale un metro
	const int PIXELES_POR_METRO = 50;

	//Variables de la ventana del programa
	Vector2i dimensiones_ventana;
	string nombre_ventana;

	//Ventana
	RenderWindow* ventana;

	//Objeto de Eventos
	Event* gestor_eventos;

	//Gravedad y mundo
	b2Vec2 gravedad;
	b2World* mundo;

	//Poligonos y Ragdoll
	Poligono* paredes[4];
	Ragdoll* ragdoll;

	//Variables para la generaci�n
	const static int LIMITE_RAGDOLLS = 5; //Define el limite para el arreglo de ragdolls
	Ragdoll* ragdolls[LIMITE_RAGDOLLS]; //Crea el arreglo de punteros

	//Obst�culos
	Poligono* obstaculos[9];

	//Ca��n
	FiguraVisual* arma[2];

	//La distancia desde el cursor hasta la base del ca�on, en pixeles
	float angulo_arma;
	float distancia_a_cursor;

	Vector2f fuerza_impulso;

public:

	//Constructor
	Simulacion(Vector2i dimensiones_programa, string nombre_programa);

	//M�todos sin retorno
	void iniciarSimulacion();
	void actualizarRenderizado();
	void gestionarEventos();
	void crearSala();
	void crearObstaculos();
	void crearArma();
	void actualizarFisicas(int iteraciones_velocidad, int iteraciones_posicion);
	void actualizarObjetos();
	void actualizarMecanicasMovimiento(float potencia_impulso);
	void aplicarFuerza(b2Body* cuerpo, b2Vec2 valor);
	void crearRagdoll(Vector2f fuerza_impulso);
	void eliminarRagdoll();

	//M�todos con retorno de datos
	RenderWindow* crearVentana(int altura, int anchura, string nombre);

	//M�todos de depuraci�n
	void depurarTransformacion(Poligono objeto);
	void depurarEstadoArreglo();

};

