#pragma once

#include "Poligono.h"

class Enlace {

private:

	//Arreglo de puntos representando la l�nea gr�fica
	VertexArray puntos_visuales;

	//Definici�n y Junta de Revoluci�n
	b2RevoluteJointDef definicion;
	b2RevoluteJoint* junta;

	//Referencias locales para objetos recibidos por par�metro al crear la junta
	Poligono* objeto_a;
	Poligono* objeto_b;
	b2Vec2 coordenadas_ancla_a;
	b2Vec2 coordenadas_ancla_b;

public:

	//Constructor
	Enlace(Poligono* objeto1, Poligono* objeto2, b2Vec2 coordenadas_ancla1, b2Vec2 coordenadas_ancla2, b2World* mundo, int pixeles_por_metro);

	//M�todos sin retorno
	void renderizar(RenderWindow* ventana);
	void actualizar(int pixeles_por_metro);

	//M�todos con retorno de dato
	Poligono* retornarPoligonoA();
	Poligono* retornarPoligonoB();

};

